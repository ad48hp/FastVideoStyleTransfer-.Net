﻿Imports System.Drawing
Imports System.Windows.Forms

Namespace FastStyleTransfer
    Partial Public Class FastStyleTransferDemo
        Private components As System.ComponentModel.IContainer = Nothing

        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing AndAlso (components IsNot Nothing) Then
                components.Dispose()
            End If

            MyBase.Dispose(disposing)
        End Sub

        Private Sub InitializeComponent()
            Dim CBlendItems1 As ProgBar.cBlendItems = New ProgBar.cBlendItems()
            Dim CFocalPoints1 As ProgBar.cFocalPoints = New ProgBar.cFocalPoints()
            Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FastStyleTransferDemo))
            Me.StyleLabel = New System.Windows.Forms.Label()
            Me.StyleComboBox = New System.Windows.Forms.ComboBox()
            Me.StylizeButton = New System.Windows.Forms.Button()
            Me.StylePictureBox = New System.Windows.Forms.PictureBox()
            Me.DisPictureBox = New System.Windows.Forms.PictureBox()
            Me.SrcPictureBox = New System.Windows.Forms.PictureBox()
            Me.label1 = New System.Windows.Forms.Label()
            Me.Label2 = New System.Windows.Forms.Label()
            Me.Label3 = New System.Windows.Forms.Label()
            Me.ProgBarPlus1 = New ProgBar.ProgBarPlus()
            Me.Label4 = New System.Windows.Forms.Label()
            Me.TextBox1 = New System.Windows.Forms.TextBox()
            Me.TextBox2 = New System.Windows.Forms.TextBox()
            Me.Label5 = New System.Windows.Forms.Label()
            Me.Label6 = New System.Windows.Forms.Label()
            Me.TextBox3 = New System.Windows.Forms.TextBox()
            Me.Label7 = New System.Windows.Forms.Label()
            Me.TextBox4 = New System.Windows.Forms.TextBox()
            Me.CheckBox1 = New System.Windows.Forms.CheckBox()
            Me.TabControl1 = New System.Windows.Forms.TabControl()
            Me.TabPage1 = New System.Windows.Forms.TabPage()
            Me.Button1 = New System.Windows.Forms.Button()
            Me.ListBox1 = New System.Windows.Forms.ListBox()
            Me.CheckBox2 = New System.Windows.Forms.CheckBox()
            Me.Label8 = New System.Windows.Forms.Label()
            Me.TextBox5 = New System.Windows.Forms.TextBox()
            Me.CheckBox3 = New System.Windows.Forms.CheckBox()
            Me.Label9 = New System.Windows.Forms.Label()
            CType(Me.StylePictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.DisPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
            CType(Me.SrcPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.TabControl1.SuspendLayout()
            Me.TabPage1.SuspendLayout()
            Me.SuspendLayout()
            '
            'StyleLabel
            '
            Me.StyleLabel.AutoSize = True
            Me.StyleLabel.Location = New System.Drawing.Point(12, 300)
            Me.StyleLabel.Name = "StyleLabel"
            Me.StyleLabel.Size = New System.Drawing.Size(63, 13)
            Me.StyleLabel.TabIndex = 15
            Me.StyleLabel.Text = "Select Style"
            '
            'StyleComboBox
            '
            Me.StyleComboBox.FormattingEnabled = True
            Me.StyleComboBox.Location = New System.Drawing.Point(95, 295)
            Me.StyleComboBox.Name = "StyleComboBox"
            Me.StyleComboBox.Size = New System.Drawing.Size(121, 21)
            Me.StyleComboBox.TabIndex = 14
            '
            'StylizeButton
            '
            Me.StylizeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.StylizeButton.Font = New System.Drawing.Font("Curlz MT", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.StylizeButton.Location = New System.Drawing.Point(699, 300)
            Me.StylizeButton.Name = "StylizeButton"
            Me.StylizeButton.Size = New System.Drawing.Size(115, 46)
            Me.StylizeButton.TabIndex = 13
            Me.StylizeButton.Text = "Transfer"
            Me.StylizeButton.UseVisualStyleBackColor = True
            '
            'StylePictureBox
            '
            Me.StylePictureBox.BackColor = System.Drawing.Color.Silver
            Me.StylePictureBox.Location = New System.Drawing.Point(50, 36)
            Me.StylePictureBox.Name = "StylePictureBox"
            Me.StylePictureBox.Size = New System.Drawing.Size(223, 248)
            Me.StylePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.StylePictureBox.TabIndex = 12
            Me.StylePictureBox.TabStop = False
            '
            'DisPictureBox
            '
            Me.DisPictureBox.BackColor = System.Drawing.Color.Silver
            Me.DisPictureBox.Location = New System.Drawing.Point(554, 36)
            Me.DisPictureBox.Name = "DisPictureBox"
            Me.DisPictureBox.Size = New System.Drawing.Size(223, 248)
            Me.DisPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.DisPictureBox.TabIndex = 11
            Me.DisPictureBox.TabStop = False
            '
            'SrcPictureBox
            '
            Me.SrcPictureBox.BackColor = System.Drawing.Color.Silver
            Me.SrcPictureBox.Location = New System.Drawing.Point(303, 36)
            Me.SrcPictureBox.Name = "SrcPictureBox"
            Me.SrcPictureBox.Size = New System.Drawing.Size(223, 248)
            Me.SrcPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.SrcPictureBox.TabIndex = 10
            Me.SrcPictureBox.TabStop = False
            '
            'label1
            '
            Me.label1.AutoSize = True
            Me.label1.Location = New System.Drawing.Point(9, 441)
            Me.label1.Name = "label1"
            Me.label1.Size = New System.Drawing.Size(48, 13)
            Me.label1.TabIndex = 19
            Me.label1.Text = "Progress"
            '
            'Label2
            '
            Me.Label2.AutoSize = True
            Me.Label2.Location = New System.Drawing.Point(300, 9)
            Me.Label2.Name = "Label2"
            Me.Label2.Size = New System.Drawing.Size(80, 13)
            Me.Label2.TabIndex = 20
            Me.Label2.Text = "Current content"
            '
            'Label3
            '
            Me.Label3.AutoSize = True
            Me.Label3.Location = New System.Drawing.Point(551, 9)
            Me.Label3.Name = "Label3"
            Me.Label3.Size = New System.Drawing.Size(69, 13)
            Me.Label3.TabIndex = 21
            Me.Label3.Text = "Current rezult"
            '
            'ProgBarPlus1
            '
            Me.ProgBarPlus1.BarBackColor = System.Drawing.Color.Red
            CBlendItems1.iColor = New System.Drawing.Color() {System.Drawing.Color.White, System.Drawing.Color.White}
            CBlendItems1.iPoint = New Single() {0!, 1.0!}
            Me.ProgBarPlus1.BarColorBlend = CBlendItems1
            Me.ProgBarPlus1.BarColorSolid = System.Drawing.Color.Lime
            Me.ProgBarPlus1.BarColorSolidB = System.Drawing.Color.Red
            Me.ProgBarPlus1.BarLengthValue = CType(25, Short)
            Me.ProgBarPlus1.BarPadding = New System.Windows.Forms.Padding(0)
            Me.ProgBarPlus1.BarStyleFill = ProgBar.ProgBarPlus.eBarStyle.Solid
            Me.ProgBarPlus1.BarStyleLinear = System.Drawing.Drawing2D.LinearGradientMode.Horizontal
            Me.ProgBarPlus1.BarStyleTexture = Nothing
            Me.ProgBarPlus1.BorderWidth = CType(1, Short)
            Me.ProgBarPlus1.Corners.All = CType(0, Short)
            Me.ProgBarPlus1.Corners.LowerLeft = CType(0, Short)
            Me.ProgBarPlus1.Corners.LowerRight = CType(0, Short)
            Me.ProgBarPlus1.Corners.UpperLeft = CType(0, Short)
            Me.ProgBarPlus1.Corners.UpperRight = CType(0, Short)
            Me.ProgBarPlus1.CylonInterval = CType(1, Short)
            Me.ProgBarPlus1.CylonMove = 5.0!
            CFocalPoints1.CenterPoint = CType(resources.GetObject("CFocalPoints1.CenterPoint"), System.Drawing.PointF)
            CFocalPoints1.FocusScales = CType(resources.GetObject("CFocalPoints1.FocusScales"), System.Drawing.PointF)
            Me.ProgBarPlus1.FocalPoints = CFocalPoints1
            Me.ProgBarPlus1.Location = New System.Drawing.Point(59, 440)
            Me.ProgBarPlus1.Name = "ProgBarPlus1"
            Me.ProgBarPlus1.ShapeTextFont = New System.Drawing.Font("Arial Black", 30.0!)
            Me.ProgBarPlus1.Size = New System.Drawing.Size(752, 24)
            Me.ProgBarPlus1.TabIndex = 22
            Me.ProgBarPlus1.TextFormat = "Process {1}% Done"
            Me.ProgBarPlus1.Value = 0
            '
            'Label4
            '
            Me.Label4.AutoSize = True
            Me.Label4.Location = New System.Drawing.Point(12, 478)
            Me.Label4.Name = "Label4"
            Me.Label4.Size = New System.Drawing.Size(31, 13)
            Me.Label4.TabIndex = 23
            Me.Label4.Text = "Input"
            '
            'TextBox1
            '
            Me.TextBox1.AllowDrop = True
            Me.TextBox1.Location = New System.Drawing.Point(49, 475)
            Me.TextBox1.Name = "TextBox1"
            Me.TextBox1.Size = New System.Drawing.Size(765, 20)
            Me.TextBox1.TabIndex = 24
            '
            'TextBox2
            '
            Me.TextBox2.AllowDrop = True
            Me.TextBox2.Location = New System.Drawing.Point(57, 504)
            Me.TextBox2.Name = "TextBox2"
            Me.TextBox2.Size = New System.Drawing.Size(757, 20)
            Me.TextBox2.TabIndex = 25
            '
            'Label5
            '
            Me.Label5.AutoSize = True
            Me.Label5.Location = New System.Drawing.Point(12, 511)
            Me.Label5.Name = "Label5"
            Me.Label5.Size = New System.Drawing.Size(39, 13)
            Me.Label5.TabIndex = 26
            Me.Label5.Text = "Output"
            '
            'Label6
            '
            Me.Label6.AutoSize = True
            Me.Label6.Location = New System.Drawing.Point(679, 421)
            Me.Label6.Name = "Label6"
            Me.Label6.Size = New System.Drawing.Size(37, 13)
            Me.Label6.TabIndex = 27
            Me.Label6.Text = "Status"
            '
            'TextBox3
            '
            Me.TextBox3.BackColor = System.Drawing.Color.White
            Me.TextBox3.Location = New System.Drawing.Point(722, 417)
            Me.TextBox3.Name = "TextBox3"
            Me.TextBox3.ReadOnly = True
            Me.TextBox3.Size = New System.Drawing.Size(85, 20)
            Me.TextBox3.TabIndex = 28
            '
            'Label7
            '
            Me.Label7.AutoSize = True
            Me.Label7.Location = New System.Drawing.Point(31, 331)
            Me.Label7.Name = "Label7"
            Me.Label7.Size = New System.Drawing.Size(49, 13)
            Me.Label7.TabIndex = 29
            Me.Label7.Text = "Resize Y"
            '
            'TextBox4
            '
            Me.TextBox4.Location = New System.Drawing.Point(85, 326)
            Me.TextBox4.Name = "TextBox4"
            Me.TextBox4.ReadOnly = True
            Me.TextBox4.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.TextBox4.Size = New System.Drawing.Size(87, 20)
            Me.TextBox4.TabIndex = 30
            Me.TextBox4.Text = "500"
            '
            'CheckBox1
            '
            Me.CheckBox1.AutoSize = True
            Me.CheckBox1.Location = New System.Drawing.Point(12, 332)
            Me.CheckBox1.Name = "CheckBox1"
            Me.CheckBox1.Size = New System.Drawing.Size(15, 14)
            Me.CheckBox1.TabIndex = 31
            Me.CheckBox1.UseVisualStyleBackColor = True
            '
            'TabControl1
            '
            Me.TabControl1.Controls.Add(Me.TabPage1)
            Me.TabControl1.Location = New System.Drawing.Point(226, 291)
            Me.TabControl1.Name = "TabControl1"
            Me.TabControl1.SelectedIndex = 0
            Me.TabControl1.Size = New System.Drawing.Size(441, 130)
            Me.TabControl1.TabIndex = 32
            '
            'TabPage1
            '
            Me.TabPage1.BackColor = System.Drawing.Color.Red
            Me.TabPage1.Controls.Add(Me.Button1)
            Me.TabPage1.Controls.Add(Me.ListBox1)
            Me.TabPage1.Controls.Add(Me.CheckBox2)
            Me.TabPage1.Controls.Add(Me.Label8)
            Me.TabPage1.Controls.Add(Me.TextBox5)
            Me.TabPage1.ForeColor = System.Drawing.Color.Lime
            Me.TabPage1.Location = New System.Drawing.Point(4, 22)
            Me.TabPage1.Name = "TabPage1"
            Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
            Me.TabPage1.Size = New System.Drawing.Size(433, 104)
            Me.TabPage1.TabIndex = 0
            Me.TabPage1.Text = "Advanced options"
            '
            'Button1
            '
            Me.Button1.BackColor = System.Drawing.Color.Lime
            Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
            Me.Button1.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.Button1.ForeColor = System.Drawing.Color.Yellow
            Me.Button1.Location = New System.Drawing.Point(7, 51)
            Me.Button1.Name = "Button1"
            Me.Button1.Size = New System.Drawing.Size(160, 44)
            Me.Button1.TabIndex = 33
            Me.Button1.Text = "Single transfer test"
            Me.Button1.UseVisualStyleBackColor = False
            '
            'ListBox1
            '
            Me.ListBox1.FormattingEnabled = True
            Me.ListBox1.Items.AddRange(New Object() {"conv1", "conv2", "conv3", "resid1", "resid2", "resid3", "resid4", "resid5", "convT1", "convT2", "convT3"})
            Me.ListBox1.Location = New System.Drawing.Point(179, 0)
            Me.ListBox1.Name = "ListBox1"
            Me.ListBox1.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple
            Me.ListBox1.Size = New System.Drawing.Size(235, 95)
            Me.ListBox1.TabIndex = 36
            '
            'CheckBox2
            '
            Me.CheckBox2.AutoSize = True
            Me.CheckBox2.Enabled = False
            Me.CheckBox2.Location = New System.Drawing.Point(7, 9)
            Me.CheckBox2.Name = "CheckBox2"
            Me.CheckBox2.Size = New System.Drawing.Size(15, 14)
            Me.CheckBox2.TabIndex = 35
            Me.CheckBox2.UseVisualStyleBackColor = True
            '
            'Label8
            '
            Me.Label8.AutoSize = True
            Me.Label8.Location = New System.Drawing.Point(25, 9)
            Me.Label8.Name = "Label8"
            Me.Label8.Size = New System.Drawing.Size(49, 13)
            Me.Label8.TabIndex = 33
            Me.Label8.Text = "Resize X"
            '
            'TextBox5
            '
            Me.TextBox5.Location = New System.Drawing.Point(80, 3)
            Me.TextBox5.Name = "TextBox5"
            Me.TextBox5.ReadOnly = True
            Me.TextBox5.RightToLeft = System.Windows.Forms.RightToLeft.No
            Me.TextBox5.Size = New System.Drawing.Size(87, 20)
            Me.TextBox5.TabIndex = 34
            Me.TextBox5.Text = "500"
            '
            'CheckBox3
            '
            Me.CheckBox3.AutoSize = True
            Me.CheckBox3.Checked = True
            Me.CheckBox3.CheckState = System.Windows.Forms.CheckState.Checked
            Me.CheckBox3.Location = New System.Drawing.Point(12, 417)
            Me.CheckBox3.Name = "CheckBox3"
            Me.CheckBox3.Size = New System.Drawing.Size(15, 14)
            Me.CheckBox3.TabIndex = 33
            Me.CheckBox3.UseVisualStyleBackColor = True
            '
            'Label9
            '
            Me.Label9.AutoSize = True
            Me.Label9.Location = New System.Drawing.Point(31, 418)
            Me.Label9.Name = "Label9"
            Me.Label9.Size = New System.Drawing.Size(225, 13)
            Me.Label9.TabIndex = 34
            Me.Label9.Text = "Dispose tensorz after use (might save memory)"
            '
            'FastStyleTransferDemo
            '
            Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
            Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
            Me.BackColor = System.Drawing.Color.Red
            Me.BackgroundImage = Global.FastStyleTransfer.Resources.Alpine_Skyline
            Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
            Me.ClientSize = New System.Drawing.Size(826, 546)
            Me.Controls.Add(Me.Label9)
            Me.Controls.Add(Me.CheckBox3)
            Me.Controls.Add(Me.TabControl1)
            Me.Controls.Add(Me.CheckBox1)
            Me.Controls.Add(Me.TextBox4)
            Me.Controls.Add(Me.Label7)
            Me.Controls.Add(Me.TextBox3)
            Me.Controls.Add(Me.Label6)
            Me.Controls.Add(Me.Label5)
            Me.Controls.Add(Me.TextBox2)
            Me.Controls.Add(Me.TextBox1)
            Me.Controls.Add(Me.Label4)
            Me.Controls.Add(Me.ProgBarPlus1)
            Me.Controls.Add(Me.Label3)
            Me.Controls.Add(Me.Label2)
            Me.Controls.Add(Me.label1)
            Me.Controls.Add(Me.StyleLabel)
            Me.Controls.Add(Me.StyleComboBox)
            Me.Controls.Add(Me.StylizeButton)
            Me.Controls.Add(Me.StylePictureBox)
            Me.Controls.Add(Me.DisPictureBox)
            Me.Controls.Add(Me.SrcPictureBox)
            Me.DoubleBuffered = True
            Me.ForeColor = System.Drawing.Color.Lime
            Me.MaximizeBox = False
            Me.Name = "FastStyleTransferDemo"
            Me.Text = "Fast Video Style Transfer"
            CType(Me.StylePictureBox, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.DisPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
            CType(Me.SrcPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
            Me.TabControl1.ResumeLayout(False)
            Me.TabPage1.ResumeLayout(False)
            Me.TabPage1.PerformLayout()
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub
        Private WithEvents StyleLabel As Label
        Private WithEvents StyleComboBox As ComboBox
        Private WithEvents StylizeButton As Button
        Private WithEvents StylePictureBox As PictureBox
        Private WithEvents DisPictureBox As PictureBox
        Private WithEvents SrcPictureBox As PictureBox
        Private WithEvents label1 As Label
        Friend WithEvents Label2 As Label
        Friend WithEvents Label3 As Label
        Friend WithEvents ProgBarPlus1 As ProgBar.ProgBarPlus
        Friend WithEvents Label4 As Label
        Friend WithEvents TextBox1 As TextBox
        Friend WithEvents TextBox2 As TextBox
        Friend WithEvents Label5 As Label
        Friend WithEvents Label6 As Label
        Friend WithEvents TextBox3 As TextBox
        Friend WithEvents Label7 As Label
        Friend WithEvents TextBox4 As TextBox
        Friend WithEvents CheckBox1 As CheckBox
        Friend WithEvents TabControl1 As TabControl
        Friend WithEvents TabPage1 As TabPage
        Friend WithEvents ListBox1 As ListBox
        Friend WithEvents Label8 As Label
        Friend WithEvents TextBox5 As TextBox
        Private WithEvents Button1 As Button
        Friend WithEvents CheckBox2 As CheckBox
        Friend WithEvents CheckBox3 As CheckBox
        Friend WithEvents Label9 As Label
    End Class
End Namespace
