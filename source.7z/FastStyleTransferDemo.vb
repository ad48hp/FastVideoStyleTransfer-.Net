﻿Imports AlbiruniML
Imports alb = AlbiruniML.Ops
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Drawing.Imaging
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports System.Windows.Forms
Imports System.Diagnostics
Imports System.Threading
Imports System.IO

Namespace FastStyleTransfer
    Partial Public Class FastStyleTransferDemo
        Inherits Form

        Public Sub New()
            InitializeComponent()
        End Sub

        Private tnet As TransformNet

        Public Shared Function ResizeImage(ByVal image As Bitmap, ByVal width As Integer, ByVal height As Integer) As Bitmap
            Dim destRect = New Rectangle(0, 0, width, height)
            Dim destImage = New Bitmap(width, height)
            destImage.SetResolution(image.HorizontalResolution, image.VerticalResolution)
            Using lGraphics = Graphics.FromImage(destImage)
                lGraphics.CompositingMode = CompositingMode.SourceCopy
                lGraphics.CompositingQuality = CompositingQuality.HighQuality
                lGraphics.InterpolationMode = InterpolationMode.HighQualityBilinear
                lGraphics.SmoothingMode = SmoothingMode.HighQuality
                lGraphics.PixelOffsetMode = PixelOffsetMode.HighQuality
                Using lWrapMode = New ImageAttributes()
                    lWrapMode.SetWrapMode(WrapMode.TileFlipXY)
                    lGraphics.DrawImage(image, destRect, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, lWrapMode)
                End Using
            End Using
            Return destImage
        End Function

        Private imageTensor As Tensor

        Private Function Image2Tensor(ByVal bmptm As Bitmap) As Tensor
            Dim x = alb.buffer(New Integer() {bmptm.Height, bmptm.Width, 3})
            For i As Integer = 0 To bmptm.Height - 1
                For j As Integer = 0 To bmptm.Width - 1
                    Dim clr As Color = bmptm.GetPixel(j, i)
                    Dim red As Single = clr.R / 255.0F
                    Dim green As Single = clr.G / 255.0F
                    Dim blue As Single = clr.B / 255.0F
                    x.[Set](red, i, j, 0)
                    x.[Set](green, i, j, 1)
                    x.[Set](blue, i, j, 2)
                Next
            Next
            Return x.toTensor()
        End Function

        Private Function Tensor2Image(ByVal dataobject As Object) As Bitmap
            Dim data As Tensor = TryCast(dataobject, Tensor)
            Dim bmptm As Bitmap = New Bitmap(data.Shape(0), data.Shape(1))
            For i As Integer = 0 To bmptm.Width - 1
                For j As Integer = 0 To bmptm.Height - 1
                    Dim col = Color.FromArgb(CInt((data.[Get](i, j, 0) * 255.0F)), CInt((data.[Get](i, j, 1) * 255.0F)), CInt((data.[Get](i, j, 2) * 255.0F)))
                    bmptm.SetPixel(i, j, col)
                Next
            Next
            data.dispose()
            bmptm.RotateFlip(RotateFlipType.Rotate90FlipX)
            Return bmptm
        End Function

        Friend Delegate Sub FormInvok()
        Friend Delegate Sub FormInvokWithParam(ByVal param As Object)
        Private t As Thread

        Private Sub TransferButton_Click(ByVal sender As Object, ByVal e As EventArgs) Handles StylizeButton.Click
            DirectCast(sender, Button).Enabled = False
            If ControlPropz() Then
                Dim myfilez As FileInfo()
                myfilez = New DirectoryInfo(TextBox1.Text).GetFiles()
                For i = 1 To myfilez.Length
                    Dim myfile As FileInfo
                    myfile = myfilez(i - 1)
                    If Not File.Exists(TextBox2.Text + "/" + myfile.Name) Then
                        mybitmp69 = LoadImg(myfile.FullName, True)
                        SrcPictureBox.Image = mybitmp69
                        Me.imageTensor = Image2Tensor(mybitmp69)
                        Me.imageTensor.keep()
                        p = tnet.Predict(Me.imageTensor)
                        mybitmp69 = Tensor2Image(p)
                        If CheckBox3.Checked Then
                            p.dispose()
                        End If
                        mybitmp69.Save(TextBox2.Text + "/" + myfile.Name)
                        DisPictureBox.Image = mybitmp69
                    End If
                Next
            End If
            DirectCast(sender, Button).Enabled = True
        End Sub

        Private Function LoadImg(nametm As String, resiz As Boolean) As Bitmap
            Dim mybit69 As Bitmap
            Using myrdr As New FileStream(nametm, FileMode.Open)
                mybit69 = New Bitmap(myrdr)
            End Using
            If resiz AndAlso CheckBox1.Checked Then
                If Not CheckBox2.Checked Then
                    mybit69 = ResizeImage(mybit69, Math.Floor(Double.Parse(Integer.Parse(TextBox4.Text)) * (Double.Parse(mybit69.Width) / (Double.Parse(mybit69.Height)))), Integer.Parse(TextBox4.Text))
                Else
                    mybit69 = ResizeImage(mybit69, Integer.Parse(TextBox5.Text), Integer.Parse(TextBox4.Text))
                End If
            End If
            Return mybit69
        End Function

        Private Function ControlPropz() As Boolean
            TextBox1.Text = TextBox1.Text.Replace("\", "/")
            TextBox2.Text = TextBox2.Text.Replace("\", "/")
            While TextBox1.Text.EndsWith("/")
                TextBox1.Text = TextBox1.Text.Substring(0, TextBox1.Text.Length - 1)
            End While
            While TextBox2.Text.EndsWith("/")
                TextBox2.Text = TextBox2.Text.Substring(0, TextBox2.Text.Length - 1)
            End While
            If Not Directory.Exists(TextBox1.Text) Then
                MessageBox.Show("Source directory doesn't exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return False
            End If
            If Not Directory.Exists(TextBox2.Text) Then
                MessageBox.Show("Destination directory doesn't exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return False
            End If
            If Not Integer.TryParse(TextBox4.Text, 1) Then
                MessageBox.Show("Image size isn't an integer.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return False
            End If
            If Not Integer.TryParse(TextBox5.Text, 1) Then
                MessageBox.Show("Resize X isn't an integer.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return False
            End If
            Return True
        End Function

        Private Sub FastStyleTransferDemo_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Shown
            tnet = New TransformNet()
            picklzbox = ListBox1
            DispozeTenzorz = CheckBox3
            AddHandler tnet.ReportProgress, AddressOf tnet_ReportProgress
            For Each item In tnet.variableDictionary
                Me.StyleComboBox.Items.Add(item.Key)
            Next
            If File.Exists(Application.StartupPath + "/options") Then
                Dim myreader As New StreamReader("options")
                ReadString(myreader, TextBox1.Text)
                ReadString(myreader, TextBox2.Text)
                Dim mystr69 As String
                mystr69 = ""
                ReadString(myreader, mystr69)
                ReadBool(myreader, CheckBox1.Checked)
                ReadString(myreader, TextBox4.Text)
                ReadBool(myreader, CheckBox2.Checked)
                ReadString(myreader, TextBox5.Text)
                Dim mystr86 As String
                mystr86 = ""
                ReadString(myreader, mystr86)
                Dim mystr95 As String()
                mystr95 = mystr86.Split(New String() {"-"}, StringSplitOptions.RemoveEmptyEntries)
                For Each mystr6997 In mystr95
                    ListBox1.SelectedIndices.Add(Integer.Parse(mystr6997.Replace("-", "")))
                Next
                ReadBool(myreader, CheckBox3.Checked)
                myreader.Close()
                If Not mystr69 = "" Then
                    Dim mylizt(StyleComboBox.Items.Count) As String
                    StyleComboBox.Items.CopyTo(mylizt, 0)
                    StyleComboBox.SelectedIndex = mylizt.ToList().IndexOf(mystr69)
                Else
                    StyleComboBox.SelectedIndex = 0
                End If
            Else
                StyleComboBox.SelectedIndex = 0
            End If
            If ListBox1.SelectedIndices.Count = 0 Then
                For i = 1 To ListBox1.Items.Count
                    ListBox1.SelectedIndices.Add(i - 1)
                Next
            End If
            Me.StylePictureBox.Image = New Bitmap("styles/" + StyleComboBox.Items(StyleComboBox.SelectedIndex).ToString() + ".jpg")
        End Sub

        Private Sub ReadInteger(myrdr69 As StreamReader, ByRef mytni As Integer)
            If Not myrdr69.EndOfStream Then
                Dim mystr6969 As String
                mystr6969 = myrdr69.ReadLine()
                If Integer.TryParse(mystr6969, 1) Then
                    mytni = Integer.Parse(mystr6969)
                End If
            End If
        End Sub

        Private Sub ReadBool(myrdr69 As StreamReader, ByRef mybl As Boolean)
            If Not myrdr69.EndOfStream Then
                Dim mystr69 As String
                mystr69 = myrdr69.ReadLine().ToLower()
                If mystr69 = "true" Then
                    mybl = True
                End If
                If mystr69 = "false" Then
                    mybl = False
                End If
            End If
        End Sub

        Private Sub ReadString(myrdr69 As StreamReader, ByRef mytxt As String)
            If Not myrdr69.EndOfStream Then
                mytxt = myrdr69.ReadLine()
            End If
        End Sub

        Private Sub tnet_ReportProgress(ByVal progress As Integer)
            Me.Invoke(New FormInvokWithParam(AddressOf UpdateProgress), progress)
        End Sub

        Private Sub UpdateProgress(ByVal value As Object)
            ProgBarPlus1.Value = Convert.ToInt32(value)
            Application.DoEvents()
        End Sub

        Private Sub StyleComboBox_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles StyleComboBox.SelectedIndexChanged
            Me.StylePictureBox.Image = New Bitmap("styles/" & Me.StyleComboBox.SelectedItem.ToString() & ".jpg")
            Me.tnet.ChangeVariable(Me.StyleComboBox.SelectedItem.ToString())
        End Sub

        Private Sub FastStyleTransferDemo_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles Me.FormClosing
            If t IsNot Nothing Then
                If t.IsAlive Then
                    t.Abort()
                End If
            End If
            Dim mywriter As New StreamWriter("options")
            mywriter.WriteLine(TextBox1.Text)
            mywriter.WriteLine(TextBox2.Text)
            mywriter.WriteLine(StyleComboBox.Items(StyleComboBox.SelectedIndex))
            mywriter.WriteLine(CheckBox1.Checked.ToString())
            mywriter.WriteLine(TextBox4.Text)
            mywriter.WriteLine(CheckBox2.Checked.ToString())
            mywriter.WriteLine(TextBox5.Text)
            mywriter.WriteLine(String.Join("-", ListBox1.SelectedIndices.Cast(Of Integer)))
            mywriter.WriteLine(CheckBox3.Checked)
            mywriter.Close()
        End Sub

        Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
            TextBox4.ReadOnly = Not DirectCast(sender, CheckBox).Checked
            CheckBox2.Enabled = DirectCast(sender, CheckBox).Checked
            If Not DirectCast(sender, CheckBox).Checked OrElse Not CheckBox2.Checked Then
                TextBox5.ReadOnly = True
            Else
                TextBox5.ReadOnly = False
            End If
        End Sub

        Private Sub TextBox1_DragEnter(sender As Object, e As DragEventArgs) Handles TextBox2.DragEnter, TextBox1.DragEnter
            If e.Data.GetDataPresent(DataFormats.FileDrop) Then
                e.Effect = DragDropEffects.Copy
            End If
        End Sub

        Private Sub TextBox1_DragDrop(sender As Object, e As DragEventArgs) Handles TextBox2.DragDrop, TextBox1.DragDrop
            Dim files As String() = e.Data.GetData(DataFormats.FileDrop)
            If files.Length = 1 Then
                DirectCast(sender, TextBox).Text = files(0)
            End If
        End Sub

        Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged
            If Not DirectCast(sender, CheckBox).Checked OrElse Not CheckBox2.Checked Then
                TextBox5.ReadOnly = True
            Else
                TextBox5.ReadOnly = False
            End If
        End Sub

        Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
            DirectCast(sender, Button).Enabled = False
            If ControlPropz() Then
                Dim myfilez As FileInfo()
                myfilez = New DirectoryInfo(TextBox1.Text).GetFiles()
                If myfilez.Length > 0 Then
                    mybitmp69 = LoadImg(myfilez(0).FullName, True)
                    SrcPictureBox.Image = mybitmp69
                    Me.imageTensor = Image2Tensor(mybitmp69)
                    Me.imageTensor.keep()
                    p = tnet.Predict(Me.imageTensor)
                    mybitmp69 = Tensor2Image(p)
                    If Checkbox3.checked Then
                        p.dispose()
                    End If
                    DisPictureBox.Image = mybitmp69
                    End If
                End If
            DirectCast(sender, Button).Enabled = True
        End Sub
    End Class
End Namespace
