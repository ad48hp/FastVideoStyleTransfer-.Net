﻿Namespace FastStyleTransfer.Properties
    <Global.System.Runtime.CompilerServices.CompilerGeneratedAttribute()>
    <Global.System.CodeDom.Compiler.GeneratedCodeAttribute("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "11.0.0.0")>
    Friend NotInheritable Partial Class Settings
        Inherits Global.System.Configuration.ApplicationSettingsBase

        Private Shared defaultInstance As Settings = (CType((Global.System.Configuration.ApplicationSettingsBase.Synchronized(New Settings())), Settings))

        Public Shared ReadOnly Property [Default] As Settings
            Get
                Return defaultInstance
            End Get
        End Property
    End Class
End Namespace
