﻿Imports AlbiruniML
Imports System.Drawing
Imports System.Windows.Forms

Module Module1
    Public p As Tensor
    Public mybitmp69 As Bitmap
    Public picklzbox As ListBox
End Module
